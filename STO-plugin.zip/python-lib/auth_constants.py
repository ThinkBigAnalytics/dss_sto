'''
Created on Sep 18, 2017

@author: dt186022
'''

MASTER_PASSWORD = """t3r@d@t@dW@ll3t"""
SECRET_KEY = """s3cr3t"""
AUTH_FILENAME = "encrypted.txt"

